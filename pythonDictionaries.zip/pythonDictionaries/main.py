#from replit import clear
from turtle import clearscreen

from art import logo

print(logo)

bids = {}
finished_bidding = False


def find_winner_bidders(bidders_record):
    highest_bid = 0
    winner = ""
    for bidders in bidders_record:
        bid_amount = bidders_record[bidders]
        if bid_amount > highest_bid:
            highest_bid = bid_amount
            winner = bidders
    print(f"The winner is {winner} with the bid: ${highest_bid}")


while not finished_bidding:
    name = input("What's your name? ")
    price = int(input("What's the price? $"))
    bids[name] = price

    to_continue = input("Is there anyone to continue bidding? then type 'yes' otherwise type 'no'? ")

    if to_continue == "no":
        finished_continue = True
        find_winner_bidders(bids)
    else:
        clearscreen()
