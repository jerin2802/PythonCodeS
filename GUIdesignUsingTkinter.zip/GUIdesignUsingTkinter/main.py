from tkinter import *


def calculation():
    value = float(input.get())
    result_in_km = value * 1.609
    result.config(text=f"{result_in_km}")


window = Tk()
window.title("My GUI project")
window.config(padx=20)

# LABEL

label_1 = Label(text="Mile to kilometer converter!!", font=("Arial", 15, "bold"))
label_1.grid(column=1, row=0)


#input value
input = Entry(width=20)
input.grid(column=1, row=1)


label_mile = Label(text="Miles", font=("Arial", 10, "normal"))
label_mile.grid(column=2, row=1)


label_result = Label(text="Is equal to", font=("Arial", 10, "normal"))
label_result.grid(column=0, row=2)

# result
result = Label(text="0", font=("Arial", 10, "normal"))
result.grid(column=1, row=2)

label_Km = Label(text="Km", font=("Arial", 10, "normal"))
label_Km.grid(column=2, row=2)


#BUTTON 1
button_1 = Button(text="calculate", command=calculation)
button_1.grid(column=1, row=3)


window.mainloop()
