alphabet = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'a', 'b', 'c',
    'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
    's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

from art import logo

print(logo)


# Don't change the code above 👆


# WAY - 1
# def caesar(main_text, shift_amount):
#   cipher_text = ""
#   if direction == "encode":
#     for letter in main_text:
#       position = alphabet.index(letter)
#       new_position = position + shift_amount
#       new_letter = alphabet[new_position]
#       cipher_text += new_letter
#     print(f"The encoded text is: {cipher_text}")

#   else:
#     plain_text = ""
#     for letter in main_text:
#       position = alphabet.index(letter)
#       new_position = position - shift_amount
#       new_letter = alphabet[new_position]
#       plain_text += new_letter
#     print(f"The decoded text is: {plain_text}")

# caesar(main_text= text, shift_amount = shift)


# WAY - 2
def caesar(main_text, shift_amount, cipher_direction):
    final_text = ""
    if cipher_direction == "decode":
        shift_amount *= -1
    for char in main_text:
        # for checking any kind of symbol/numbers/space user inputs as a text to encode. if we get any of them we we'll append them directly without shifting....
        if char in alphabet:
            position = alphabet.index(char)
            new_position = position + shift_amount
            new_letter = alphabet[new_position]
            final_text += new_letter

        else:
            final_text += char

    print(f"The {cipher_direction}d text is: {final_text}")


# User inputs
to_continue = True
while to_continue:
    direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
    text = input("Type your message:\n").lower()
    shift = int(input("Type the shift number:\n"))
    shift = shift % 26

    caesar(main_text=text, shift_amount=shift, cipher_direction=direction)

    wish = input("Type 'yes if you want to go again. Otherwise type 'no' for exit!\n")
    if wish == "no":
        to_continue = False
        print("GOODBYE!!")
