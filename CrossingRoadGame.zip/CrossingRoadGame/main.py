import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from score import Score

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

player = Player()
car_manager = CarManager()
score = Score()

screen.listen()
screen.onkey(player.run, "Up")

game_on = True
while game_on:
    time.sleep(0.1)
    screen.update()

    car_manager.create_car()
    car_manager.move()
    score.update_level()

    #detect collision with cars
    for car in car_manager.cars:
        if car.distance(player) < 25:
            game_on = False
            # for another overview for game over!
            time.sleep(0.5)
            screen.clear()
            screen.bgcolor("black")
            score.game_finish()

    #detect successful crossing
    if player.finished_run():
        player.start_run()
        car_manager.level_up()
        score.increase_level()

screen.exitonclick()
