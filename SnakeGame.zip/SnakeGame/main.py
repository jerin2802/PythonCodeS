from turtle import Screen

from food import Food
from score import Score
from snake import Snake
import time

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("#ADFC6C")
screen.title("Snake Game")
screen.tracer(0)

snake = Snake()
food = Food()
score = Score()

screen.listen()
screen.onkey(snake.up, "Up")
screen.onkey(snake.down, "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right, "Right")

game_on = True
while game_on:
    screen.update()
    time.sleep(0.1)
    snake.move()

    # COLLISION WITH FOOD AND GET SCORE
    if snake.head.distance(food) < 15:
        food.refresh()
        snake.extend_snake()
        score.total_score()

    #COLLISION WITH SCREEN_WALL
    if snake.head.xcor() > 300 or snake.head.xcor() < -300 or snake.head.ycor() > 300 or snake.head.ycor() < -300:
        game_on = False
        score.game_over()

    # COLLISION WITH SNAKE TAIL
    for segment in snake.snakes[1:]:
        if snake.head.distance(segment) < 10:
            game_on = False
            score.game_over()


screen.exitonclick()
