from turtle import Turtle

SNAKE_POSITIONS = [(0, 0), (-20, 0), (-40, 0)]
MOVE_DISTANCE = 20
RIGHT = 0
UP = 90
LEFT = 180
DOWN = 270


class Snake:

    def __init__(self):
        self.snakes = []
        self.create_snake()
        self.head = self.snakes[0]

    def create_snake(self):
        for position in SNAKE_POSITIONS:
            self.add_new_segment(position)

    def add_new_segment(self, position):
        new_segment = Turtle()
        new_segment.shape("square")
        new_segment.color("black")
        new_segment.penup()
        new_segment.goto(position)
        self.snakes.append(new_segment)

    def extend_snake(self):
        self.add_new_segment(self.snakes[-1].position())
        # here -1 indexing means it will add anew segment from the last part of the snake

    def move(self):  # to move forward
        for seg_num in range(len(self.snakes) - 1, 0, -1):  # range(start,stop, step)
            new_x = self.snakes[seg_num - 1].xcor()
            new_y = self.snakes[seg_num - 1].ycor()
            self.snakes[seg_num].goto(new_x, new_y)
        self.head.forward(MOVE_DISTANCE)

    def right(self):  # to move Right at 0 degree
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)

    def up(self):  # to move UP at 90 degree
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def left(self):  # to move LEFT at 180 degree
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def down(self):  # to move DOWN at 270 degree
        if self.head.heading() != UP:
            self.head.setheading(DOWN)
