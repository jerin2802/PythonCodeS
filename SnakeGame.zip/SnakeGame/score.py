from turtle import Turtle

ALIGN = "right"
FONT = ("Arial", 15, "normal")


class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.total = 0
        self.color("blue")
        self.hideturtle()
        self.penup()
        self.goto(260, 260)
        self.write(f"Score: {self.total}", move=False, align=ALIGN, font=FONT)

    def total_score(self):
        self.total += 1
        self.clear()
        self.write(f"Score: {self.total}", move=False, align="right", font=("Arial", 15, "normal"))

    def game_over(self):
        self.clear()
        self.goto(0, 0)
        self.write("GAME OVER!!", align="center", font=FONT)
        self.goto(0, -20)
        self.color("purple")
        self.write(f"Final Score: {self.total}", move=False, align="center", font=FONT)

