from turtle import Turtle


class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.color("white")
        self.penup()
        self.hideturtle()
        self.l_point = 0
        self.r_point = 0
        self.update_score()

    def update_score(self):
        self.clear()
        self.goto(-100, 200)
        self.write(self.l_point, align="center", font=("calibre", 40, "normal"))
        self.goto(100, 200)
        self.write(self.r_point, align="center", font=("calibre", 40, "normal"))

    def r_score(self):
        self.r_point += 1
        self.update_score()

    def l_score(self):
        self.l_point += 1
        self.update_score()

    def finish_game(self):
        self.color("purple")
        self.penup()
        self.hideturtle()
        self.goto(0, 0)
        self.write("You missed ball 5 times.....", align="center", font=("calibre", 25, "normal"))
        self.goto(0, -40)
        self.color("cyan")
        self.write("Game Over!!", align="center", font=("calibre", 30, "normal"))
