from turtle import Screen
import time

from ball import Ball
from puddle import Puddle
from score import Score

screen = Screen()
screen.bgcolor("black")
screen.setup(width=800, height=600)
screen.title("Pong Game")
screen.tracer(0)

r_puddle = Puddle((370, 0))
l_puddle = Puddle((-370, 0))
ball = Ball()
score = Score()

screen.listen()
screen.onkey(r_puddle.up, "Up")
screen.onkey(r_puddle.down, "Down")

screen.onkey(l_puddle.up, "w")
screen.onkey(l_puddle.down, "s")

game_on = True
count = 5
while game_on:
    time.sleep(ball.speed_up)
    screen.update()
    ball.move()

    # detect bottom wall collision
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()

    # detect collision of ball with r_puddle/ l_puddle
    if (ball.distance(l_puddle) < 50 and ball.xcor() < -340) or (ball.distance(r_puddle) < 50 and ball.xcor() > 340):
        ball.bounce_x()

    """# If misses any ball to touch puddle then the ball will 
         start from the center point and moves opposite direction..."""

    # for missing ball from Right puddle
    if ball.xcor() > 380:
        ball.reset_position()
        score.l_score()
        count -= 1

    # for missing ball from Left puddle
    if ball.xcor() < -380:
        ball.reset_position()
        score.r_score()
        count -= 1

    if count == 0:
        game_on = False
        score.finish_game()

screen.exitonclick()
