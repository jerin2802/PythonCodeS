import turtle as t
import random
#import colorgram

tim = t.Turtle()
# #Extract color code
# rgb_colors = []
# colors = colorgram.extract('hist_image.jpg', 20)
# for color in colors:
#     r = color.rgb.r
#     g = color.rgb.g
#     b = color.rgb.b
#     new_color = (r, g, b)
#     rgb_colors.append(new_color)
#
# print(rgb_colors)

tim.penup()
tim.hideturtle()
tim.speed("fastest")

t.colormode(255)
#color list which we got from extracting clr code
color = [(213, 154, 96), (52, 107, 132), (179, 77, 31), (202, 142, 31),
         (115, 155, 171), (124, 79, 99), (122, 175, 156), (226, 198, 131),
         (192, 87, 108), (11, 50, 64), (55, 38, 19), (228, 92, 77),
         (45, 168, 126), (47, 127, 123), (200, 121, 143), (168, 21, 29)]
number_of_dots = 100

tim.setheading(225)
tim.forward(300)

for dots in range(1, number_of_dots + 1):
    tim.dot(20, random.choice(color))
    tim.setheading(0)
    tim.forward(50)
    if dots % 10 == 0:
        tim.setheading(90)
        tim.forward(50)
        tim.setheading(180)
        tim.forward(500)
        tim.setheading(0)

screen = t.Screen()
screen.exitonclick()
