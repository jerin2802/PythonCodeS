from turtle import Turtle, Screen
import random

screen = Screen()
screen.setup(width=500, height=400)
user_bet = screen.textinput("Make a bet",
                            "which turtle will you want to bet? Enter a color")
race_continue = False
colors = ["red", "yellow", "green", "purple", "blue", "orange"]
speeds = ["slowest", "slow", "normal", "fast", "fastest"]
all_turtles = []
x = -230
y = -75

for set_turtle in range(0, 6):
    new_turtle = Turtle(shape="turtle")
    new_turtle.penup()
    new_turtle.color(colors[set_turtle])
    new_turtle.goto(x, y)
    y += 30
    all_turtles.append(new_turtle)

if user_bet:
    race_continue = True

while race_continue:
    for turtle in all_turtles:
        moves = random.randint(2, 10)
        turtle.forward(moves)
    if turtle.xcor() > 230:
       race_continue = False
       winning_turtle = turtle.pencolor()

       if winning_turtle == user_bet:
          print(f"you won! The winner is {winning_turtle} turtle.")
       else:
          print(f"you lose! The winner is {winning_turtle} turtle.")



screen.exitonclick()
