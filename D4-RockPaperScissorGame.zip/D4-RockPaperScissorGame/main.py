import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

game_img = [rock, paper, scissors]

user = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors.\n"))

#Checking invalid inputs for this game.
if (user >=3) or (user < 0):
  print("It's a invalid number for this game. Try again!")
else:
  print(game_img[user])

  #random input for computer
  computer = random.randint(0,2)
  print(game_img[computer])

  #checking toses/patterns
  if user == 0 and computer == 2:
    print("you win!!")
  elif user < computer and computer ==2:
    print("you lose.")
  elif user < computer:
    print("you win!!")
  elif computer == 0 and user == 2:
    print("you lose.")
  elif computer < user and user == 2:
    print("you win!!")
  elif computer < user:
    print("you lose.")
  else:
    print("It's draw...")
