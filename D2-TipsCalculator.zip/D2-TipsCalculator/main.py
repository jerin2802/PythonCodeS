#welcome text
print("Welcome to the tip calculator.")

#taking user inputs
bill = input("What was the total bill? $")
tip = input("What percentage tip would you like to give? 10, 12 or 15? ")
person = input("How many people to split the bill? ")

#let's get to the calculation
bill_new = float(bill) #convert type string to int
tip_new = int(tip) / 100
tip_to_give = bill_new * tip_new #calculate the tip
total_bill = tip_to_give + bill_new #calculate the total bill including tip
per_to_give = total_bill / int(person) #how much bill per person to pay
per_person_amount = round(per_to_give, 2) #by using this format sometimes it doesn't show the 2 place number after decimal(it shows 33.6 not this 33.60)
per_person_amount = "{:.2f}".format(per_to_give) #to avoid previous problem we can use this
print(f"Each person should pay: ${per_person_amount}")
