print("""
            .-._   _ _ _ _ _ _ _ _
         .-''-.__.-'00  '-' ' ' ' ' ' ' ' '-.
         '.___ '    .   .--_'-' '-' '-' _'-' '._
          V: V 'vv-'   '_   '.       .'  _..' '.'.
            '=.____.=_.--'   :_.__.__:_   '.   : :
                    (((____.-'        '-.  /   : :
          snd                         (((-'\ .' /
                                    _____..'  .'
                                   '-._____.-'
""")

# print statement
print("Welcome to where is my water game? \n")
print("Your mission is to find the water for a crocodile.\n")

question1 = input('Do you wanna got to "left" or "right"?\n').lower()

# first block
if question1 == "left":
    question2 = input('Do you want to "wait" for a while or "pump" a cycle?\n').lower()

    # second stage block
    if question2 == "pump":
        question3 = input('Which flag you want to choose? red, purple or blue?\n').lower()

        # third stage block
        if question3 == "purple":
            print("You're in wrong section with poisonous water. Game Over!")
        elif question3 == "red":
            print("Gosh! you just burned yorself by fire. Game Over!")
        elif question3 == "blue":
            print("WOOH! you got the key of pipeline. You Win!!!")
        else:
            print("you typed wrong color which doesn't exist. Game Over!")

    else:
        print("You just got a blocked way. Game Over!!")

else:
    print("you just fall into a hole. Game Over!!!")
