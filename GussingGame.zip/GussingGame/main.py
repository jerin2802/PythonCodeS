from random import randint
from art import logo

answer = randint(1, 100)
easy_turns = 10
hard_turns = 5


def set_difficulty():
    level = input("Choose difficulty. Type 'easy' or 'hard' as level: ")

    if level == 'easy':
        return easy_turns
    else:
        return hard_turns


def check_number(guess, answer, turns):
    if guess > answer:
        print("Too high.")
        return turns - 1
    elif guess < answer:
        print("Too low.")
        return turns - 1
    else:
        print(f"You got it!!! Your answer is {guess}")


def play_game():
    print(logo)

    print("Welcome to the Number Guessing Game...")
    print("I'm thinking of taking a number between 1 to 100.")

    guess = 0
    turns = set_difficulty()

    while guess != answer:
        print(f"you have {turns} attempts remaining to guess the number.")
        guess = int(input("Make a guess: "))
        turns = check_number(guess, answer, turns)
        if turns == 0:
            print("You have no attempts to guess. You lose!!")
            return
        elif guess != answer:
            print("Guess again!")


# call play_game function to play.....
play_game()
