from art import logo

print(logo)


# Add
def add(n1, n2):
    return n1 + n2


# Subtract
def subtract(n1, n2):
    return n1 - n2


# multiply
def multiply(n1, n2):
    return n1 * n2


# divide
def divide(n1, n2):
    return n1 / n2


# operations dictionary
operations = {
    "+": add,
    "-": subtract,
    "*": multiply,
    "/": divide
}


def calculator():
    # User inputs
    num1 = float(input("what's the first number? "))

    # print operations to choose
    for symbol in operations:
        print(symbol)

    to_continue = True
    while to_continue:

        chosen_operation = input("Choose an operation symbol to calculate from the above line: ")

        num2 = float(input("what's the second number? "))

        # calculation function
        calculation_function = operations[chosen_operation]
        answer = calculation_function(num1, num2)

        print(f"\nResult is: {num1} {chosen_operation} {num2} = {answer}")

        choice = input("Type 'y' to continue calculating with the result or type 'n' to start a new calculation: ")

        if choice == 'y':
            num1 = answer
        else:
            to_continue = False
            calculator()


calculator()
