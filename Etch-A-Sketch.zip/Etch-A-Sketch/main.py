from turtle import Turtle, Screen,clearscreen

tim = Turtle()
screen = Screen()
screen.listen()
def move_forward():
    tim.forward(10)
def move_backward():
    tim.backward(20)
def turn_left():
    new_heading = tim.heading() + 10
    tim.setheading(new_heading)
def turn_right():
    new_heading = tim.heading() - 10
    tim.setheading(new_heading)
def clear_screen():
    screen.clear()
    tim = Turtle()


screen.onkey(move_forward, "f")
screen.onkey(move_backward, "b")
screen.onkey(turn_left, "l")
screen.onkey(turn_right, "r")
screen.onkey(clear_screen, "c")


screen.exitonclick()


