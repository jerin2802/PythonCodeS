row1 = ["⬜️","️⬜️","️⬜️"]
row2 = ["⬜️","⬜️","️⬜️"]
row3 = ["⬜️️","⬜️️","⬜"]
map = [row1, row2, row3]
print(f"{row1}\n{row2}\n{row3}")

#it takes a value wher 1st digit will indicate column and last digit will indicate row..
position = input("Where do you want to put the treasure?\n")

horizontal = int(position[0])
vertical = int(position[1])
#At that case we vabe to mapped row then column. That's why we use 1st vertical indices and then horizontal.
map[vertical-1][horizontal-1] = ' X'
#We decrease 1 because we all know in python indexing starts with 0 to so on....

print(f"{row1}\n{row2}\n{row3}")
